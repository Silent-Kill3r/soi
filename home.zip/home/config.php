<?php
// setting scama
$yourmail  = "";  // your email 
$namerand = "silent";  // name for file rzult *
$pass = "Fahad78"; // pass admin panel
$botToken="6533665505:AAGKed57Ovz7OZe0xBPWxpt7ua7Z7JbmQ84"; // token bot telegram
$chatId="5101640713";  // chatId telegram

?>